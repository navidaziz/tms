          <div class="row" style="padding: 10px 25px;">
            <!-- col-md-offset-1 -->
                <div class="col-md-12">
               
                  <?php echo validation_errors(); ?>
                  <form class="form-horizontal" method="post" enctype="multipart/form-data" id="role_form" action="<?php echo base_url('school/school_update_by_school_user_after_copying_data_process');?>">
                    <?php  date_default_timezone_set("Asia/Karachi"); $dated = date("d-m-Y h:i:sa");?>
                    <input type="hidden" name="school_id" value="<?php echo $school_id; ?>" />
                    <input type="hidden" name="createdDate" value="<?php echo $dated; ?>">
                    <div class="box-body">

                      <div class="form-group">
                         <strong class="col-sm-2 text-right">Registration:</strong>
                         <label class="radio-inline col-sm-2">
                         <input type="radio" name="reg_type_id" checked="" class="flat-red" value="2"> Renewal </label>
                         <label class="radio-inline col-sm-4">
                         <input type="radio" name="reg_type_id" class="flat-red" value="4"> Up-Gradation And Renewal </label>
                      </div>

                   
                      <div class="form-group">
                          <div class="col-md-2 col-sm-offset-10">
                              <button type="submit"  style="margin-left:15px;" class="btn btn-primary btn-flat">Proceed</button>
                          </div>
                      </div>
                    </div>
                  </form>

                </div>
            </div>
