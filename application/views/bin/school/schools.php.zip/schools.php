  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h2 style="display:inline;">
        <?php echo @ucfirst($title); ?>
      </h2>
      <small><?php echo @$description; ?></small>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <!-- <li><a href="#">Examples</a></li> -->
        <li class="active"><?php echo @ucfirst($title); ?>s</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

        <div class="box box-primary box-solid">
          <div class="box-header with-border">
            <h3 class="box-title"><?php echo @ucfirst($title); ?>s list</h3>
            <!-- /.box-tools -->
          </div>
          <!-- /.box-header -->
          <div class="box-body">
            <div class="pull-right margin-b">
              <!-- <a href="<?php echo base_url('school/create_form'); ?>" class="btn btn-flat btn-primary">Add new <?php echo @ucfirst($title); ?></a> -->
            </div>
              <?php $role_id = $this->session->userdata('role_id');?>
              <div class="row">
                <div class="col-md-12">
                  <div class="">
                  <table class="table table-responsive table-hover table-bordered table-condensed">
                    <tbody>
                    <tr>
                      <th style="width: 10px">ID</th>
                      <th>School Name</th>
                      <th>Registration Number</th>
                      <th>Address</th>
                      <th>Phone#</th>
                      <th>Cell#</th>
                      <th>Type</th>
                      <th>School Owner</th> 
                      <th>School Level</th>
                      <th>School For</th>
                      <th class="text-center">Actions</th>
                    </tr>
                    <?php $counter= 1; ?>
                    <?php foreach($schools as $school): ?>
                    <tr>
                      <td><?php echo $school->schoolId; ?></td>
                      <td><a class="btn btn-link" href="<?php echo base_url('school/explore_schools_by_school_id/'); ?><?php echo $school->schoolId; ?>"><?php echo $school->schoolName; ?></a></td>
                      <td><?php if($school->registrationNumber == 0 && $role_id != 16): ?>
                        <a href="<?php echo base_url('school/registration_code_allotment/'); ?>">Allot Registration Number</a>
                      <?php else: echo $school->registrationNumber; endif;?></td>
                      <td><?php if($school->districtTitle != NULL){
                                    echo $school->districtTitle.", ".$school->address;
                                  }else{
                                    echo $school->address;
                                  }
                          ?>   
                      </td>
                      <td><?php echo $school->telePhoneNumber; ?></td>
                      <td><?php echo $school->schoolMobileNumber; ?></td>
                      <td><?php echo @$school->typeTitle; ?></td>
                      <td><?php echo @$school->userTitle; ?></td>
                      <td><?php echo @$school->levelofInstituteTitle; ?></td>
                      <td><?php echo $school->genderOfSchoolTitle; ?></td>
                      <td class="text-center">
                        <a href="<?php echo base_url('school/explore_schools_by_school_id/'); ?><?php echo $school->schoolId; ?>" title="Explore the <?php echo @ucfirst($title); ?>"> &nbsp;<i class="fa fa-eye"></i></a>
                        <a href="<?php echo base_url('school/edit/'); ?><?php echo $school->schoolId; ?>" title="Edit <?php echo @ucfirst($title); ?>"> &nbsp;<i class="fa fa-edit"></i></a>
                        <a href="<?php echo base_url('school/delete/'); ?><?php echo $school->schoolId; ?>" title="Delete <?php echo @ucfirst($title); ?>"> &nbsp;<i class="fa fa-trash-o text-danger"></i></a>
                      </td>
                    </tr>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                  </div>
                  <?= $this->pagination->create_links(); ?>
                </div>
              </div>
          </div>
          <!-- /.box-body -->
        </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


  <!-- Modal -->
  <div class="modal fade" id="modal_one" role="dialog" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" id="modal_one_title">title will be goes dynamically</h4>
        </div>
        <div id="modal_one_content_goes_here">
          
        </div>
      </div>
      
    </div>
  </div>



  <script type="text/javascript">
      function load_form_in_modal(id, title, url) {

          $.ajax({
              type: 'POST',
              url: "<?php echo base_url('')?>"+url,
              data: {"id": id},

              success: function(data){
                  $('#modal_one').modal('show');
                  $("#modal_one_content_goes_here").html(data);
                  $("#modal_one_title").html(title);

              },
               error:function (data) {
                 // alert("getUcsByTehsilsId :s"+data);

               }

          });
        // $('#myModal').modal('show');

        
      }
  </script>